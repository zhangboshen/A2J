import cv2
import torch
import torch.nn as nn
import torch.optim.lr_scheduler as lr_scheduler
import numpy as np
import scipy.io as scio
import os
from PIL import Image
import time
import datetime
import logging
from torch.autograd import Variable
import sys
import matplotlib.pyplot as plt
import model_depthreg_noncomp as model
import anchor_depthreg_noncomp  as anchor
#import anchor
from tqdm import tqdm
import random_erasing
from shutil import copyfile


os.environ["CUDA_VISIBLE_DEVICES"] = "2"

# DataHyperParms 
keypointsNumber = 15
#cropWidth = 224
#cropHeight = 224
batch_size = 256
batch_size_test = 256
learning_rate = 0.00035
Weight_Decay = 1e-4
nepoch = 27

RegLossFactor = 5

RandCropShift = 15
RandshiftDepth = 5
Use_Normal = False

DATASET = 'ITOP_side'


if DATASET == 'ITOP_side':
    RandRotate = 45 ## +- 30
    RandScale = (0.4, 0.8)
    spatialFactor = 1
    depth_thres = 0.5
    trainingImageDir = '/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_train/depthImages/'
    testingImageDir = '/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_test/depthImages/'
    keypointsfile = '/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_train/keypoints3D.mat'
    keypointsfileTest = '/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_test/keypoints3D.mat'
    bndboxfile = '/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_train/bndbox.mat'
    bndbox_test = scio.loadmat('/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_test/FRbndbox_test.mat' )['FRbndbox_test']   
    #bndbox_test = scio.loadmat('./data/side_test/bndbox.mat')['bndbox']  ## GT bndbox
    Img_mean = np.load('/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_train/mean_crop_train.npy')[3]
    Img_std = np.load('/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_train/std_crop_train.npy')[3]
    #Img_mean = np.load('./data/side_train/bndboxCropMinusCenter_mean.npy')
    #Img_std = np.load('./data/side_train/bndboxCropMinusCenter_std.npy')

    center_train = scio.loadmat('/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_test/side_train_center.mat')['centre_pixel']
    center_test = scio.loadmat('/data/zhangboshen/CODE/Anchor_Pose_fpn/data/side_test/side_test_center.mat')['centre_pixel']
    cropWidth = 288
    cropHeight = 288
    save_dir = './RegLossFactor_5'
    depthFactor = 50


elif DATASET == 'ITOP_top':
    RandRotate = 30 ## +- 30
    RandScale = (0.4, 0.8)
    spatialFactor = 1
    depth_thres = 1.4
    trainingImageDir = './data/top_train/depthImages/'
    testingImageDir = './data/top_test/depthImages/'
    keypointsfile = './data/top_train/keypoints3D.mat'
    keypointsfileTest = './data/top_test/keypoints3D.mat'
    bndboxfile = './data/top_train/bndbox.mat'
    bndbox_test = scio.loadmat('./data/top_test/FRbndbox_test.mat'  )['FRbndbox_test']   
    #bndbox_test = scio.loadmat('./data/top_test/bndbox.mat')['bndbox']  ## GT bndbox
    Img_mean = np.load('./data/top_train/mean_crop_train.npy')[3]
    Img_std = np.load('./data/top_train/std_crop_train.npy')[3]
    #Img_mean = np.load('./data/top_train/top_bndboxCropMinusCenter_mean.npy')
    #Img_std = np.load('./data/top_train/top_bndboxCropMinusCenter_std.npy')
    
    
    center_train = scio.loadmat('./data/top_test/top_train_center.mat')['centre_pixel']
    center_test = scio.loadmat('./data/top_test/top_test_center.mat')['centre_pixel']
    cropWidth = 192
    cropHeight = 192
    save_dir = './Results_ITOP_top/no_center_depthfactor_spatial1_reg2_192192'
    depthFactor = 50


try:
    os.makedirs(save_dir)
except OSError:
    pass


def pixel2world(x,y,z):
    worldX = (x - 160.0)*z*0.0035
    worldY = (120.0 - y)*z*0.0035
    return worldX,worldY
    
def world2pixel(x,y,z):
    pixelX = 160.0 + x / (0.0035 * z)
    pixelY = 120.0 - y / (0.0035 * z)
    return pixelX,pixelY
    
# loading labels
print('loading keypoints labels')
keypoints_mat = scio.loadmat(keypointsfile)
keypointsWorld = keypoints_mat['keypoints3D']   # 17991*15*3
keypointsWorld = keypointsWorld.astype(np.float32)
print('keypointsWorld_shape',np.shape(keypointsWorld))
keypointsPixel = np.ones((len(keypointsWorld),15,2),dtype='float32')
keypointsPixel_tuple = world2pixel(keypointsWorld[:,:,0],keypointsWorld[:,:,1],keypointsWorld[:,:,2])
assert np.shape(keypointsPixel_tuple[0])==(len(keypointsWorld),15), "data transform error!"
keypointsPixel[:,:,0] = keypointsPixel_tuple[0]
keypointsPixel[:,:,1] = keypointsPixel_tuple[1]
print('keypointsPixel_shape',np.shape(keypointsPixel))


# loading labels
print('loading keypoints labels (testingImages)')
keypoints_matTest = scio.loadmat(keypointsfileTest)
keypointsWorldtest = keypoints_matTest['keypoints3D']   # 17991*15*3
keypointsWorldtest = keypointsWorldtest.astype(np.float32)
print('testing keypointsWorldtest_shape',np.shape(keypointsWorldtest))
keypointsPixeltest = np.ones((len(keypointsWorldtest),15,2),dtype='float32')
keypointsPixeltest_tuple = world2pixel(keypointsWorldtest[:,:,0],keypointsWorldtest[:,:,1],keypointsWorldtest[:,:,2])
assert np.shape(keypointsPixeltest_tuple[0])==(len(keypointsWorldtest),15), "data transform error!"
keypointsPixeltest[:,:,0] = keypointsPixeltest_tuple[0]
keypointsPixeltest[:,:,1] = keypointsPixeltest_tuple[1]
print('keypointsPixeltest_shape',np.shape(keypointsPixeltest))



print('loading bndbox labels')
bndbox_mat = scio.loadmat(bndboxfile)
bndbox = bndbox_mat['bndbox']   # 17991*4
bndbox = bndbox.astype(np.float32)
print('bndbox_shape',np.shape(bndbox))

print('bndbox_shape (testing time)',np.shape(bndbox_test)) 

joint_id_to_name = {
  0: 'Head',
  1: 'Neck',
  2: 'RShoulder',
  3: 'LShoulder',
  4: 'RElbow',
  5: 'LElbow',
  6: 'RHand',
  7: 'LHand',
  8: 'Torso',
  9: 'RHip',
  10: 'LHip',
  11: 'RKnee',
  12: 'LKnee',
  13: 'RFoot',
  14: 'LFoot',
}

    

def transform(img, label, matrix):
    '''
    img: H, W,  label, 14,2,   
    '''
    img_out = cv2.warpAffine(img,matrix,(cropWidth,cropHeight))
    label_out = np.ones((keypointsNumber, 3))
    label_out[:,:2] = label[:,:2].copy()
    label_out = np.matmul(matrix, label_out.transpose())
    label_out = label_out.transpose()

    return img_out, label_out


def dataPreprocess(index, img, keypointsPixel, keypointsWorld, bndbox, center, depth_thres=0.4, augment=True):
    '''
    img [H, W], 
    '''
    imageOutputs = np.ones((cropHeight, cropWidth, 1), dtype='float32') 
    labelOutputs = np.ones((keypointsNumber, 3), dtype = 'float32') 

    center_pixel = center.copy()

    if augment:
        RandomOffset_1 = np.random.randint(-1*RandCropShift,RandCropShift)
        RandomOffset_2 = np.random.randint(-1*RandCropShift,RandCropShift)
        RandomOffset_3 = np.random.randint(-1*RandCropShift,RandCropShift)
        RandomOffset_4 = np.random.randint(-1*RandCropShift,RandCropShift)
        #RandomOffsetDepth = np.random.randint(-1*RandshiftDepth,RandshiftDepth)
        RandomRotate = np.random.randint(-1*RandRotate,RandRotate)
        RandomScale = np.random.rand()*RandScale[0]+RandScale[1]
        matrix = cv2.getRotationMatrix2D((cropWidth/2,cropHeight/2),RandomRotate,RandomScale)

    else:
        RandomOffset_1, RandomOffset_2, RandomOffset_3, RandomOffset_4 = 0, 0, 0, 0
        RandomRotate = 0
        RandomScale = 1
        matrix = cv2.getRotationMatrix2D((cropWidth/2,cropHeight/2),RandomRotate,RandomScale)

    new_Xmin = max(bndbox[index][0] + RandomOffset_1, 0)
    new_Ymin = max(bndbox[index][1] + RandomOffset_2, 0)
    new_Xmax = min(bndbox[index][2] + RandomOffset_3, img.shape[1] - 1)
    new_Ymax = min(bndbox[index][3] + RandomOffset_4, img.shape[0] - 1)

    #imCrop = img.copy()[int(lefttop_pixel[index,0,1]) : int(rightbottom_pixel[index,0,1]), \
                #int(lefttop_pixel[index,0,0]) : int(rightbottom_pixel[index,0,0])]
    imCrop = img.copy()[int(new_Ymin):int(new_Ymax), int(new_Xmin):int(new_Xmax)]

    imgResize = cv2.resize(imCrop, (cropWidth, cropHeight), interpolation=cv2.INTER_NEAREST)

    imgResize = np.asarray(imgResize,dtype = 'float32')  # H*W*C

    #imgResize[np.where(imgResize >= center_pixel[index][0][2] + depth_thres)] = center_pixel[index][0][2]+depth_thres#885.4240396601466
    #imgResize[np.where(imgResize <= center_pixel[index][0][2] - depth_thres)] = center_pixel[index][0][2]-depth_thres#885.4240396601466

    imgResize = (imgResize - Img_mean) / Img_std

    #depthMin = np.min(imgResize)
    #depthMax = np.max(imgResize)
    #imgResize = 2*((imgResize-depthMin)/(depthMax-depthMin) - 0.5)  # normalize

    ## label
    label_xy = np.ones((keypointsNumber, 2), dtype = 'float32') 
    label_xy[:,0] = (keypointsPixel[index,:,0] - new_Xmin)*cropWidth/(new_Xmax - new_Xmin)
    label_xy[:,1] = (keypointsPixel[index,:,1] - new_Ymin)*cropHeight/(new_Ymax - new_Ymin) # y

    if augment:
        #imgResize += RandomOffsetDepth/depthFactor
        imgResize, label_xy = transform(imgResize, label_xy, matrix)  ## rotation, scaling
    
    imageOutputs[:,:,0] = imgResize

    labelOutputs[:,1] = label_xy[:,0]#(self.keypointsUVD[index,:,0] - new_Xmin)*cropWidth/(new_Xmax - new_Xmin) # x
    labelOutputs[:,0] = label_xy[:,1] #(self.keypointsUVD[index,:,1] - new_Ymin)*cropHeight/(new_Ymax - new_Ymin) # y
    labelOutputs[:,2] = (keypointsWorld.copy()[index,:,2])*depthFactor   # Z  )   # Z  
        
    #labelOutputs[:,2] = 2*((labelOutputs[:,2]-depthMin)/(depthMax-depthMin) - 0.5)  # normalize
    
    imageOutputs = np.asarray(imageOutputs)
    imageNCHWOut = imageOutputs.transpose(2, 0, 1)  # [H, W, C] --->>>  [C, H, W]
    imageNCHWOut = np.asarray(imageNCHWOut)
    labelOutputs = np.asarray(labelOutputs)

    data, label = torch.from_numpy(imageNCHWOut), torch.from_numpy(labelOutputs)

    return data, label



######################   Pytorch dataloader   #################
class my_dataloader(torch.utils.data.Dataset):

    def __init__(self, trainingImageDir, bndbox, keypointsPixel, keypointsWorld, center, augment=True, UseNormal=False):

        self.trainingImageDir = trainingImageDir
        self.mean = Img_mean
        self.std = Img_std
        self.bndbox = bndbox
        self.keypointsPixel = keypointsPixel
        self.keypointsWorld = keypointsWorld
        self.center = center
        self.augment = augment
        self.UseNormal = UseNormal
        self.depth_thres = 0.4
        self.randomErase = random_erasing.RandomErasing(probability = 0.5, sl = 0.02, sh = 0.4, r1 = 0.3, mean=[0],scale=0.2)

    def __getitem__(self, index):

        data4DTemp = scio.loadmat(self.trainingImageDir + str(index+1) + '.mat')['DepthNormal']       
        # depthMap
        depthTemp = data4DTemp[:,:,3]
        
        data, label = dataPreprocess(index, depthTemp, self.keypointsPixel, self.keypointsWorld, self.bndbox, self.center, self.depth_thres, self.augment)

        if self.augment:
            data = self.randomErase(data)
            #data += RandomOffsetDepth
            #labelOutputs[:,2] += RandomOffsetDepth 

        return data, label
    
    def __len__(self):
        return len(self.bndbox)

      


train_image_datasets = my_dataloader(trainingImageDir, bndbox, keypointsPixel, keypointsWorld, center_train, augment=True, UseNormal=Use_Normal)
train_dataloaders = torch.utils.data.DataLoader(train_image_datasets, batch_size = batch_size,
                                             shuffle = True, num_workers = 8)#, collate_fn = my_collate_fn) # 8 workers may work faster

val_image_datasets = my_dataloader(trainingImageDir, bndbox, keypointsPixel, keypointsWorld, center_train, augment=False, UseNormal=Use_Normal)
val_dataloaders = torch.utils.data.DataLoader(val_image_datasets, batch_size = batch_size,
                                             shuffle = False, num_workers = 8)#, collate_fn = my_collate_fn) # 8 workers may work faster

test_image_datasets = my_dataloader(testingImageDir, bndbox_test, keypointsPixeltest, keypointsWorldtest, center_test, augment=False, UseNormal=Use_Normal)
test_dataloaders = torch.utils.data.DataLoader(test_image_datasets, batch_size = batch_size_test,
                                             shuffle = False, num_workers = 8)#, collate_fn = my_collate_fn) # 8 workers may work faster

def main():
   
    net = model.Cls_Reg_Dual_Path_Net(num_classes = keypointsNumber, useNormal=Use_Normal)
    net = net.cuda()
    
    post_precess = anchor.post_process(shape=[cropHeight//16,cropWidth//16],stride=16,P_h=None, P_w=None)
    criterion = anchor.FocalLoss(shape=[cropHeight//16,cropWidth//16],thres = [16.0,32.0],stride=16,\
        spatialFactor=spatialFactor,img_shape=[cropHeight, cropWidth],P_h=None, P_w=None)

    optimizer = torch.optim.Adam(net.parameters(), lr=learning_rate, weight_decay=Weight_Decay)
    #optimizer = torch.optim.SGD(net.parameters(), lr=learning_rate, weight_decay=Weight_Decay,momentum=0.9)
    scheduler = lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.2)
    
    logging.basicConfig(format='%(asctime)s %(message)s', datefmt='%Y/%m/%d %H:%M:%S', \
                    filename=os.path.join(save_dir, 'train.log'), level=logging.INFO)
    logging.info('======================================================')

    for epoch in range(nepoch):

        net = net.train()
        scheduler.step(epoch)
        train_loss_add = 0.0
        Cls_loss_add = 0.0
        Reg_loss_add = 0.0
        timer = time.time()
    
        # Training loop
        for i, (img, label) in enumerate(train_dataloaders):

            torch.cuda.synchronize() 

            img, label = img.cuda(), label.cuda()     
            
            heads  = net(img)  
            #print(regression)     
            optimizer.zero_grad()  
            
            Cls_loss, Reg_loss = criterion(heads, label)

            loss = 1*Cls_loss + Reg_loss*RegLossFactor
            loss.backward()
            optimizer.step()

            torch.cuda.synchronize()
            
            train_loss_add = train_loss_add + (loss.item())*len(img)
            Cls_loss_add = Cls_loss_add + (Cls_loss.item())*len(img)
            Reg_loss_add = Reg_loss_add + (Reg_loss.item())*len(img)

            # printing loss info
            if i%10 == 0:
                print('epoch: ',epoch, ' step: ', i, 'Cls_loss ',Cls_loss.item(), 'Reg_loss ',Reg_loss.item(), ' total loss ',loss.item())
            if i%201 == 0:
                pred_keypoints = post_precess(heads)
                print('epoch: ',epoch, ' step: ', i, 'Cls_loss ',Cls_loss.item(), 'Reg_loss ',Reg_loss.item(), ' total loss ',loss.item())
                print('predictions: ',pred_keypoints[0:2].data.cpu().numpy())
                print('ground_truth: ',label[0:2].data.cpu().numpy()) 
                print('regression: ',heads[1][-2:-1].data.cpu().numpy())
            
        # time taken
        torch.cuda.synchronize()
        timer = time.time() - timer
        timer = timer / len(bndbox)
        print('==> time to learn 1 sample = %f (ms)' %(timer*1000))


        train_loss_add = train_loss_add / len(bndbox)
        Cls_loss_add = Cls_loss_add / len(bndbox)
        Reg_loss_add = Reg_loss_add / len(bndbox)
        print('mean train_loss_add of 1 sample: %f, #train_indexes = %d' %(train_loss_add, len(bndbox)))
        print('mean Cls_loss_add of 1 sample: %f, #train_indexes = %d' %(Cls_loss_add, len(bndbox)))
        print('mean Reg_loss_add of 1 sample: %f, #train_indexes = %d' %(Reg_loss_add, len(bndbox)))


        Accuracy_test = 0
        Accuracy_train = 0

        if (epoch % 1 == 0):  
            net = net.eval()
            output = torch.FloatTensor()
            outputTrain = torch.FloatTensor()

            for i, (img, label) in tqdm(enumerate(test_dataloaders)):
                #print(len(test_dataloaders))
                with torch.no_grad():
                    #   torch.cuda.synchronize()
                    #print(img.size())
                    img, label = img.cuda(), label.cuda()       
                    heads = net(img)  
                    pred_keypoints = post_precess(heads, voting=False)
                    output = torch.cat([output,pred_keypoints.data.cpu()], 0)

            result = output.cpu().data.numpy()
            Accuracy_test = evaluation10CMRule(result,keypointsWorldtest,bndbox_test, center_test)
            print('epoch: ', epoch, 'Test accuracy:', Accuracy_test)
            #scio.savemat(os.path.join(save_dir, 'test.mat'),{'result':result})

            for i, (img, label) in tqdm(enumerate(val_dataloaders)):
                #print(len(test_dataloaders))
                with torch.no_grad():
                    #   torch.cuda.synchronize()
                    #print(img.size())
                    img, label = img.cuda(), label.cuda()       
                    heads = net(img)  
                    pred_keypoints = post_precess(heads, voting=False)
                    outputTrain = torch.cat([outputTrain,pred_keypoints.data.cpu()], 0)

            result = outputTrain.cpu().data.numpy()
            Accuracy_train = evaluation10CMRule(result,keypointsWorld, bndbox, center_train)
            print('epoch: ', epoch, 'Train accuracy:', Accuracy_train)

            saveNamePrefix = '%s/net_%d_wetD_' % (save_dir, epoch) + str(Weight_Decay) + '_depFact_' + str(spatialFactor) + '_RegFact_' + str(RegLossFactor) + '_rndShft_' + str(RandCropShift)
            torch.save(net.state_dict(), saveNamePrefix + '.pth')
            #torch.save(optimizer.state_dict(), saveNamePrefix + '.pth')

        # log
        logging.info('Epoch#%d: total loss=%e, Cls_loss=%e, Reg_loss=%e, Acc_train=%e, Acc_test=%e, lr = %f'
        %(epoch, train_loss_add, Cls_loss_add, Reg_loss_add, Accuracy_train, Accuracy_test, scheduler.get_lr()[0]))

        
      
def test():   
    
    net = model.Cls_Reg_Dual_Path_Net(num_classes = keypointsNumber, useNormal=Use_Normal)
    net.load_state_dict(torch.load('/data/zhangboshen/CODE/Anchor_Pose_fpn/Results_ITOP_side/no_center_depthfactor_ro45_pretrain_288/net_21_wetD_0.0001_depFact_1_RegFact_3_rndShft_15.pth')) 
    #net.load_state_dict(torch.load('/data/zhangboshen/CODE/Anchor_Pose/Results/depFact50_1e4_rndShft15_posThres12_resnet34_noNorm_smoothL1_RegFac1_depthreginteg_rndErz/net_13_wetD_0.0001_depFact_50.0_RegFact_1_rndShft_15.pth')) 
    net = net.cuda()
    net.eval()
    
    #post_precess = anchor.post_process(shape=[cropHeight//8,cropWidth//8])
    post_precess = anchor.post_process(shape=[cropHeight//16,cropWidth//16],stride=16,P_h=None, P_w=None)

    output = torch.FloatTensor()
    # torch.cuda.synchronize()
    time1 = time.time()
    total_time=0 
    for i, (img, label) in tqdm(enumerate(test_dataloaders)):
        #print(len(test_dataloaders))

        with torch.no_grad():
        #torch.cuda.synchronize()
        #print(img.size())

            img, label = img.cuda(), label.cuda()
            torch.cuda.synchronize()
            start = time.time()              
            heads = net(img)  
            #bs = classification.shape[0]
            #Cls_map = classification.view(bs, 18, 24, 16, 15)
            #Cls_map = Cls_map.sum(3)
            #Cls_map = Cls_map.permute(0,2,1,3)
            #P0_map = Cls_map[:,:,:,0]
            #out2 = out1.view(batch_size, width, height, self.num_anchors, self.num_classes)

            #for idx, (x) in enumerate(heads):
            #    np.save('/data/zhangboshen/CODE/Anchor_Pose_fpn/Results_ITOP_side/Vis_itop/'+str(i)+'_'+str(idx)+'.npy',x.cpu().data.numpy())


            torch.cuda.synchronize()       
            
            pred_keypoints = post_precess(heads,voting=False)
            end = time.time()
            total_time+=end-start

            output = torch.cat([output,pred_keypoints.data.cpu()], 0)
        #torch.cuda.synchronize()
    # torch.cuda.synchronize()       
    time2 = time.time()
    print ('total_forward_time',total_time)
    print ('each_image_computing_time: ',(time2 - time1)/len(test_image_datasets))

    # save data
    result = output.cpu().data.numpy()
    Accuracy_test = evaluation10CMRule(result,keypointsWorldtest,bndbox_test, center_test)
    print('Accuracy:', Accuracy_test)
    evaluation10CMRule_perJoint(result,keypointsWorldtest,bndbox_test, center_test)

    #scio.savemat(os.path.join(save_dir, 'test.mat'),{'result':result})


def evaluation10CMRule(source, target, Bndbox, center):
    assert np.shape(source)==np.shape(target), "source has different shape with target"
    Test1_ = np.zeros(source.shape)
    Test1_[:, :, 0] = source[:,:,1]
    Test1_[:, :, 1] = source[:,:,0]
    Test1_[:, :, 2] = source[:,:,2]
    Test1 = Test1_  # [x, y, z]
    
    for i in range(len(Test1_)):

        # new_Xmin = max(bndbox[index][0], 0)
        # new_Ymin = max(bndbox[index][1], 0)
        # new_Xmax = min(bndbox[index][2], 320 - 1)
        # new_Ymax = min(bndbox[index][3], 240 - 1)
             
        Test1[i,:,0] = Test1_[i,:,0]*(Bndbox[i,2]-Bndbox[i,0])/cropWidth + Bndbox[i,0]  # x
        Test1[i,:,1] = Test1_[i,:,1]*(Bndbox[i,3]-Bndbox[i,1])/cropHeight + Bndbox[i,1]  # y
        #Test1[i,:,2] = (Test1_[i,:,2]/2 + 0.5)*(depthMax-depthMin) + depthMin
        Test1[i,:,2] = Test1_[i,:,2]/depthFactor #+ center[i][0][2]
    #scio.savemat('./itop_side_88.mat',{'resultUVD':Test1})
    TestWorld = np.ones((len(Test1),keypointsNumber,3))    
    TestWorld_tuple = pixel2world(Test1[:,:,0],Test1[:,:,1],Test1[:,:,2])
    
    TestWorld[:,:,0] = TestWorld_tuple[0]
    TestWorld[:,:,1] = TestWorld_tuple[1]
    TestWorld[:,:,2] = Test1[:,:,2]

    count = 0
    for i in range(len(source)):
        for j in range(keypointsNumber):
            if np.square(TestWorld[i,j,0] - target[i,j,0]) + np.square(TestWorld[i,j,1] - target[i,j,1]) + np.square(TestWorld[i,j,2] - target[i,j,2])<np.square(0.1): #10cm   
                count = count + 1         
    accuracy = count/(len(source)*keypointsNumber)
    return accuracy
   


def evaluation10CMRule_perJoint(source, target, Bndbox, center):
    assert np.shape(source)==np.shape(target), "source has different shape with target"
    Test1_ = np.zeros(source.shape)
    Test1_[:, :, 0] = source[:,:,1]
    Test1_[:, :, 1] = source[:,:,0]
    Test1_[:, :, 2] = source[:,:,2]
    Test1 = Test1_  # [x, y, z]
    
    for i in range(len(Test1_)):

        # new_Xmin = max(bndbox[index][0], 0)
        # new_Ymin = max(bndbox[index][1], 0)
        # new_Xmax = min(bndbox[index][2], 320 - 1)
        # new_Ymax = min(bndbox[index][3], 240 - 1)
             
        Test1[i,:,0] = Test1_[i,:,0]*(Bndbox[i,2]-Bndbox[i,0])/cropWidth + Bndbox[i,0]  # x
        Test1[i,:,1] = Test1_[i,:,1]*(Bndbox[i,3]-Bndbox[i,1])/cropHeight + Bndbox[i,1]  # y
        #Test1[i,:,2] = (Test1_[i,:,2]/2 + 0.5)*(depthMax-depthMin) + depthMin
        Test1[i,:,2] = Test1_[i,:,2]/depthFactor #+ center[i][0][2]
    TestWorld = np.ones((len(Test1),keypointsNumber,3))    
    TestWorld_tuple = pixel2world(Test1[:,:,0],Test1[:,:,1],Test1[:,:,2])
    
    TestWorld[:,:,0] = TestWorld_tuple[0]
    TestWorld[:,:,1] = TestWorld_tuple[1]
    TestWorld[:,:,2] = Test1[:,:,2]

    count = 0
    accuracy = 0
    for j in range(keypointsNumber):
        for i in range(len(source)):      
            if np.square(TestWorld[i,j,0] - target[i,j,0]) + np.square(TestWorld[i,j,1] - target[i,j,1]) + np.square(TestWorld[i,j,2] - target[i,j,2])<np.square(0.1): #10cm   
                count = count + 1     

        accuracy = count/(len(source))
        print('joint_', j,joint_id_to_name[j], ', accuracy: ', accuracy)
        accuracy = 0
        count = 0







if __name__ == '__main__':
    #copyfile('./itop_main_depthreg.py', save_dir+'/itop_main_depthreg.py')
    #copyfile('./anchor_depthreg_noncomp.py', save_dir+'/anchor_depthreg_noncomp.py')  
    ##copyfile('./model_depthreg_noncomp.py', save_dir+'/model_depthreg_noncomp.py') 
    #copyfile('./densenet.py', save_dir+'/densenet.py') 
    #copyfile('./resnet.py', save_dir+'/resnet.py') 
    #copyfile('./senet.py', save_dir+'/senet.py') 
    #copyfile('./random_erasing.py', save_dir+'/random_erasing.py') 
    #main()
    test()
    
      
